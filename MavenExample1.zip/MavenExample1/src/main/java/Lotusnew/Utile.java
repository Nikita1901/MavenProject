package Lotusnew;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;


public class Utile extends BasePage {

public void enterText (By by, String text)
 {
    driver.findElement(by).clear();
    driver.findElement(by).sendKeys(text);

 }
public void clickable (By by)
 {
    driver.findElement(by).click();
 }

public void getNewText (By by)
 {
    driver.findElement(by).getText();
 }

public String randomDate(By by)
{
    DateFormat format = new SimpleDateFormat("ddmmyyHHmmss");
    return format.format(new Date());
}

public void randomNumber(By by)
{
    Random randomNum = new Random();
}


public  void selectByValue(By by)
{
    Select select = new Select(driver.findElement(by));
    select.selectByValue(" ");
}
public void selectByIndex (By by)
{
   Select select1 =new Select(driver.findElement(by));
    select1.selectByIndex(0);
}

public void selectByVisibleText (By by)
{
   Select select2= new Select(driver.findElement(by));
    select2.selectByVisibleText(" ");
}

public void elementDisplayed (By by)
{
    driver.findElement(by).isDisplayed();
}


public void captureScreenshot (By by) throws IOException {
   File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
    FileUtils.copyFile(scrFile, new File("C:\\Users\\Chahat\\Desktop\\ScreenShotsWebdriver"));
}

public void waitForClickable (By by)
{

    WebDriverWait wait = new WebDriverWait(driver, 10);

    WebElement element = wait.until(ExpectedConditions.elementToBeClickable(by));

}

public void retryAndClick ()
{


}

}
