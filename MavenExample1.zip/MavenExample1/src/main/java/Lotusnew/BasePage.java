package Lotusnew;
import org.openqa.selenium.WebDriver;

/**
 * Created by Chahat on 19/11/2016.
 */
public class BasePage
{

    protected static WebDriver driver;


}
