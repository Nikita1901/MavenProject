package Lotusnew;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.util.concurrent.TimeUnit;

/**
 * Created by Chahat on 19/11/2016.
 */
public class BasicTest extends BasePage {

    @BeforeClass
    public void openBrowser()
   {
       driver =new FirefoxDriver();
       driver.get("http://opensource.demo.orangehrmlive.com/");
       driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);

    }

    @AfterClass
    public void closeBrowser()
    {
        driver.quit();
    }

}
