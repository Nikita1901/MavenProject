package Lotusnew;

import org.apache.http.util.Asserts;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.mustache.Value;

/**
 * Created by Chahat on 19/11/2016.
 */
public class TestSuit extends BasicTest {

//Utile = Driver, Methods
// BasePage = =
// Basic Test= before methods, after method
//TestSuit= Homepage(Assert), Login (Assert)


    Utile utile =new Utile();

@Test

    public void userHomePage ()
   {
      Assert.assertEquals(driver.findElement(By.id("btnLogin")).getAttribute("value"),"LOGIN");

       System.out.println("Test is Passed.");
   }
@Test
   public void userLogIn ()
   {
       utile.enterText(By.id("txtUsername"), "Admin");
       utile.enterText(By.id("txtPassword"),"admin");
       utile.clickable(By.id("btnLogin"));
      Assert.assertEquals(driver.findElement(By.id("welcome")).getText(), "Welcome Admin");

       System.out.println("User can Log in, test is passed");
   }
@Test
    public void userLogInwithInvalidPassword ()
{
    utile.enterText(By.id("txtUsername"), "Admin");
    utile.enterText(By.id("txtPassword")," ");
    utile.clickable(By.id("btnLogin"));
    Assert.assertEquals(driver.findElement(By.id("spanMessage")).getText(), "Invalid credentials", "Test Failed." );

    System.out.println("Please enter correct password.");
}
 @Test
    public void userLoginwithInvalidUserName ()
 {
     utile.enterText(By.id("txtUsername"), " ");
     utile.enterText(By.id("txtPassword"),"admin ");
     utile.clickable(By.id("btnLogin"));
     Assert.assertEquals(driver.findElement(By.id("spanMessage")).getText(), "Invalid credentials" );

     System.out.println("Please enter valid Username.");
 }

}
