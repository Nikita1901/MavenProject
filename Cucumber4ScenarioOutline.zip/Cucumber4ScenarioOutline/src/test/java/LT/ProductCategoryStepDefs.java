package LT;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;

/**
 * Created by Chahat on 29/11/2016.
 */
public class ProductCategoryStepDefs extends DriverManager {

    ProductCategoryLinkPage productCategoryLinkPage =new ProductCategoryLinkPage();

    @Given("^I am on a homepage$")
    public void i_am_on_a_homepage() {
        openBowser();

    }

    @When("^I click on \"([^\"]*)\"$")
    public void i_click_on(String products)  {

//       ProductCategoryLinkPage productCategoryLinkPage =new ProductCategoryLinkPage();
//        productCategoryLinkPage.productCategory();


        driver.findElement(By.linkText(products)).click();


    }

    @Then("^I should be able to see \"([^\"]*)\"$")
    public void i_should_be_able_to_see(String result)
    {
      String exp= result;
      String actual= driver.findElement(By.xpath("html/body/div[5]/div[3]/div[2]/div[2]/div/div[1]/h1")).getText();

        Assert.assertEquals(actual, exp);
       Utility utility = new Utility();
        utility.screenShotOnTestFailure(actual!=exp );

        closeBrowser();

    }
}
