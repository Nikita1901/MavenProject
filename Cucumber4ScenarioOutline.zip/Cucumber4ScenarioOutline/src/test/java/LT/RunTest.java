package LT;


import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src\\test\\Resources\\product.link.feature",

format ={ "pretty", "html:target\\html", "json:target/.json"})
public class RunTest{


}

