package LT;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.testng.ITestResult;

import java.io.File;
import java.io.IOException;

import static LT.DriverManager.driver;

/**
 * Created by Chahat on 29/11/2016.
 */
public class Utility {

    public static void clickable(WebElement element)
    {
        element.click();
    }

    public void screenShotOnTestFailure(ITestResult testResult) throws IOException{
        if (testResult.getStatus()==ITestResult.FAILURE)
        {
            File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(scrFile, new File("src\\test\\Resources.png"));
        }
    }
}
