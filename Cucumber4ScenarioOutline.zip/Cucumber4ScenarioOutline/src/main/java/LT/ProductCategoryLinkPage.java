package LT;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Created by Chahat on 29/11/2016.
 */
public class ProductCategoryLinkPage extends DriverManager {

    @FindBy(linkText = "Computers")
    private WebElement _computerCategory;

    @FindBy(linkText = "Electronics")
    private WebElement _electronicsCategory;

    @FindBy(linkText = "Apparel")
    private WebElement _apparelCategory;

    @FindBy(linkText = "Digital downloads")
    private WebElement _digitalDownloads;

    @FindBy(linkText = "Books")
    private WebElement _booksCategory;

    @FindBy(linkText = "Gift Cards")
    private WebElement _giftCards;

public void productCategory()
{
    Utility.clickable(_computerCategory);
//    Utility.clickable(_electronicsCategory);
//    Utility.clickable(_apparelCategory);
//    Utility.clickable(_digitalDownloads);
//    Utility.clickable(_booksCategory);
//    Utility.clickable(_giftCards);
}
}
